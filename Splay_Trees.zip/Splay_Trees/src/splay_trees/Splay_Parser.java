/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package splay_trees;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author champion
 */
public class Splay_Parser {
    public static void main(String[] args) throws IOException {
        System.out.println("ENter the Values: ");
            
            //Enter data using BufferReader 
        BufferedReader reader =  
                   new BufferedReader(new InputStreamReader(System.in)); 
         while(true){
               // Reading data using readLine 
        String name = reader.readLine(); 
  
        // Printing the read line 
//        System.out.println(name);
            if(name.equalsIgnoreCase("exit")){
                break;
            }

         }
         
         System.out.println("Done with Program");
      
    }
}
